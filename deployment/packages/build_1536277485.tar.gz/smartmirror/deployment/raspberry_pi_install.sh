#!/bin/bash
set -e

echo "###############################"
echo "Raspberry Pi Install"
echo "###############################"

sudo apt-get update && sudo apt-get upgrade

# Creating logging directories
sudo mkdir -p /var/log/smartmirror
sudo chown -R www-data:www-data /var/log/smartmirror
sudo chown -R pi:pi /srv/
mkdir -p /srv/smartmirror

echo "###################################"
echo " Installing Virtualenv and Wrapper"
echo "###################################"

pip install virtualenv
virtualenv /srv/virtualenv

echo "###############################"
echo " Installing Nginx"
echo "###############################"

sudo apt-get install nginx

echo "###############################"
echo " Installing uWsgi"
echo "###############################"

sudo apt-get install uwsgi-emperor uwsgi
sudo apt-get install uwsgi-plugin-python

sudo apt-get install sqlite
echo "##################################"
echo " Install Complete - Reboot the Pi"
echo "##################################"

echo "Some help commands below:"
echo "sudo service elasticseach start|status|restart "
echo "source /srv/virtualenv/bin/activate "